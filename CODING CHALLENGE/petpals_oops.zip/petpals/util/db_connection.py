import pyodbc
import configparser
import os

def get_connection():
    config = configparser.ConfigParser()
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    config.read(os.path.join(base_dir, 'db.properties'))

    try:
        connection = pyodbc.connect(
            'DRIVER={SQL Server};'
            f'SERVER={config["database"]["server"]};'
            f'DATABASE={config["database"]["dbname"]};'
            f'Trusted_Connection={config["database"]["trusted_connection"]};'
        )
        return connection
    except Exception as e:
        print(f"Error connecting to DB: {e}")
