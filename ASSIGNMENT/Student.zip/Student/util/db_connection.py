# util/db_connection.py
import pyodbc
from util.db_property_util import DBPropertyUtil
from exception.sis_exception import *

class DBConnection:
    __connection = None

    @staticmethod
    def get_connection():
        if DBConnection.__connection is None:
            try:
                connection_string = DBPropertyUtil.get_connection_string()
                DBConnection.__connection = pyodbc.connect(connection_string)
                print("Database connection established successfully")
            except Exception as e:
                print(f"Error establishing database connection: {str(e)}")
                raise DBConnectionException("Failed to connect to database")
        return DBConnection.__connection

    @staticmethod
    def close_connection():
        if DBConnection.__connection:
            DBConnection.__connection.close()
            DBConnection.__connection = None
            print("Database connection closed")