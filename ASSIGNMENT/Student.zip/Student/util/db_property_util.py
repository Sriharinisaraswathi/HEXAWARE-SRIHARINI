# util/db_property_util.py
class DBPropertyUtil:
    @staticmethod
    def get_connection_string():
        return (
            "DRIVER={SQL Server};"
            "SERVER=;LAPTOP-QBD4VNOO\MSSQLSERVER02"
            "DATABASE=StudentInfo__DB;"
            "Trusted_Connection=yes;"
        )