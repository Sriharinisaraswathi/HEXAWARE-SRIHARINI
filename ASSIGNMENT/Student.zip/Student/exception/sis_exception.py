# exception/sis_exception.py
class SISException(Exception):
    """Base exception class for SIS"""
    pass

class StudentNotFoundException(SISException):
    pass

class CourseNotFoundException(SISException):
    pass

class TeacherNotFoundException(SISException):
    pass

class DuplicateEntryException(SISException):
    pass

class DuplicateEnrollmentException(SISException):
    pass

class PaymentValidationException(SISException):
    pass

class DBConnectionException(SISException):
    pass

class StudentDAOException(SISException):
    pass

class CourseDAOException(SISException):
    pass

class EnrollmentDAOException(SISException):
    pass

class PaymentDAOException(SISException):
    pass
class TeacherDAOException(SISException):
    pass
class DBConnectionException(SISException):
    pass