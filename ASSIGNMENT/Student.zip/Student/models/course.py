class Course:
    def __init__(self, course_id, name, code, instructor=None):
        self.course_id = course_id
        self.name = name
        self.code = code
        self.instructor = instructor
        self.enrollments = []  # List of Enrollment objects

    def assign_teacher(self, teacher):
        self.instructor = teacher
        teacher.courses.append(self)

    def update_course_info(self, code, name, instructor):
        self.code = code
        self.name = name
        self.instructor = instructor

    def display_course_info(self):
        print(f"ID: {self.course_id}, Code: {self.code}, Name: {self.name}, Instructor: {self.instructor.first_name if self.instructor else 'N/A'}")

    def get_enrollments(self):
        return self.enrollments

    def get_teacher(self):
        return self.instructor
