from datetime import datetime

class SIS:
    def __init__(self):
        self.students = []
        self.courses = []
        self.teachers = []

    def add_student(self, student):
        self.students.append(student)

    def add_course(self, course):
        self.courses.append(course)

    def add_teacher(self, teacher):
        self.teachers.append(teacher)

    def add_enrollment(self, student, course, enrollment_date=datetime.now()):
        from models.enrollment import Enrollment
        enrollment = Enrollment(len(course.enrollments) + 1, student, course, enrollment_date)
        student.enrollments.append(enrollment)
        course.enrollments.append(enrollment)

    def assign_course_to_teacher(self, course, teacher):
        if course not in teacher.courses:
            teacher.courses.append(course)
        course.instructor = teacher

    def add_payment(self, student, amount, payment_date=datetime.now()):
        from models.payment import Payment
        payment = Payment(len(student.payments) + 1, student, amount, payment_date)
        student.payments.append(payment)

    def get_enrollments_for_student(self, student):
        return student.enrollments

    def get_courses_for_teacher(self, teacher):
        return teacher.courses

    def enroll_student_in_course(self, student, course):
        self.add_enrollment(student, course)

    def assign_teacher_to_course(self, teacher, course):
        self.assign_course_to_teacher(course, teacher)

    def record_payment(self, student, amount, payment_date=datetime.now()):
        self.add_payment(student, amount, payment_date)

    def generate_enrollment_report(self, course):
        print(f"\nEnrollments for {course.name}:")
        for enrollment in course.get_enrollments():
            student = enrollment.get_student()
            print(f"- {student.first_name} {student.last_name} (ID: {student.student_id})")

    def generate_payment_report(self, student):
        print(f"\nPayments made by {student.first_name} {student.last_name}:")
        for payment in student.get_payment_history():
            print(f"- Amount: {payment.get_payment_amount()}, Date: {payment.get_payment_date()}")

    def calculate_course_statistics(self, course):
        enrollments = course.get_enrollments()
        num_enrollments = len(enrollments)
        total_payments = 0
        for enrollment in enrollments:
            student = enrollment.get_student()
            total_payments += sum([payment.get_payment_amount() for payment in student.get_payment_history()])
        print(f"\nCourse: {course.name}")
        print(f"Total Enrollments: {num_enrollments}")
        print(f"Total Payments from Enrolled Students: {total_payments}")
