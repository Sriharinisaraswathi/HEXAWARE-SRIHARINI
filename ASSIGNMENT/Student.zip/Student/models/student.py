from datetime import datetime

class Student:
    def __init__(self, student_id, first_name, last_name, dob, email, phone):
        self.student_id = student_id
        self.first_name = first_name
        self.last_name = last_name
        self.dob = dob
        self.email = email
        self.phone = phone
        self.enrollments = []  # List of Enrollment objects
        self.payments = []     # List of Payment objects

    def enroll_in_course(self, course):
        from models.enrollment import Enrollment
        enrollment = Enrollment(len(self.enrollments) + 1, self, course, datetime.now())
        self.enrollments.append(enrollment)
        course.enrollments.append(enrollment)

    def update_student_info(self, first_name, last_name, dob, email, phone):
        self.first_name = first_name
        self.last_name = last_name
        self.dob = dob
        self.email = email
        self.phone = phone

    def make_payment(self, amount, payment_date):
        from models.payment import Payment
        payment = Payment(len(self.payments) + 1, self, amount, payment_date)
        self.payments.append(payment)

    def display_student_info(self):
        print(f"ID: {self.student_id}, Name: {self.first_name} {self.last_name}, DOB: {self.dob}, Email: {self.email}, Phone: {self.phone}")

    def get_enrolled_courses(self):
        return [enrollment.course for enrollment in self.enrollments]

    def get_payment_history(self):
        return self.payments
