class Payment:
    def __init__(self, payment_id, student, amount, payment_date):
        self.payment_id = payment_id
        self.student = student
        self.amount = amount
        self.payment_date = payment_date

        # Automatically add this payment to the student's payment history
        if self not in student.payments:
            student.payments.append(self)

    def get_student(self):
        return self.student

    def get_payment_amount(self):
        return self.amount

    def get_payment_date(self):
        return self.payment_date

    def display_payment_info(self):
        print(f"Payment ID: {self.payment_id}, Student: {self.student.first_name} {self.student.last_name}, "
              f"Amount: ₹{self.amount}, Date: {self.payment_date}")
