class Enrollment:
    def __init__(self, enrollment_id, student, course, date):
        self.enrollment_id = enrollment_id
        self.student = student
        self.course = course
        self.date = date

        # Automatically add this enrollment to both student and course
        if self not in student.enrollments:
            student.enrollments.append(self)
        if self not in course.enrollments:
            course.enrollments.append(self)

    def get_student(self):
        return self.student

    def get_course(self):
        return self.course

    def display_enrollment_info(self):
        print(f"Enrollment ID: {self.enrollment_id}, Student: {self.student.first_name} {self.student.last_name}, "
              f"Course: {self.course.name}, Date: {self.date}")
