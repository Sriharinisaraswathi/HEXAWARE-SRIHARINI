class Teacher:
    def __init__(self, teacher_id, first_name, last_name, email):
        self.teacher_id = teacher_id
        self.first_name = first_name
        self.last_name = last_name
        self.email = email
        self.courses = []  # List to store assigned Course objects

    def assign_course(self, course):
        if course not in self.courses:
            self.courses.append(course)
            course.instructor = self  # Set the course's instructor

    def update_teacher_info(self, name, email, _):
        self.first_name, self.last_name = name.split()
        self.email = email

    def display_teacher_info(self):
        print(f"ID: {self.teacher_id}, Name: {self.first_name} {self.last_name}, Email: {self.email}")

    def get_assigned_courses(self):
        return self.courses
