from abc import ABC, abstractmethod
from models.student import Student
from models.teacher import Teacher
from models.course import Course
from models.enrollment import Enrollment
from models.payment import Payment
from typing import List

class SISDaoInterface(ABC):
    @abstractmethod
    def add_student(self, student: Student) -> bool:
        pass
    
    @abstractmethod
    def get_student(self, student_id: int) -> Student:
        pass
    
    @abstractmethod
    def add_teacher(self, teacher: Teacher) -> bool:
        pass
    
    @abstractmethod
    def get_teacher(self, teacher_id: int) -> Teacher:
        pass
    
    @abstractmethod
    def add_course(self, course: Course) -> bool:
        pass
    
    @abstractmethod
    def get_course(self, course_id: int) -> Course:
        pass
    
    @abstractmethod
    def enroll_student(self, enrollment: Enrollment) -> bool:
        pass
    
    @abstractmethod
    def get_enrollments_by_student(self, student_id: int) -> List[Enrollment]:
        pass
    
    @abstractmethod
    def get_enrollments_by_course(self, course_id: int) -> List[Enrollment]:
        pass
    
    @abstractmethod
    def record_payment(self, payment: Payment) -> bool:
        pass
    
    @abstractmethod
    def get_payments_by_student(self, student_id: int) -> List[Payment]:
        pass
    
    @abstractmethod
    def update_course_teacher(self, course_id: int, teacher_id: int) -> bool:
        pass
    
    @abstractmethod
    def close_connection(self):
        pass