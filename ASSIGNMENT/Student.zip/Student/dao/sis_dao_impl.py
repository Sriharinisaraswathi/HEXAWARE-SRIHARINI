# dao/sis_dao_impl.py
from dao.sis_dao_interface import SISDaoInterface
from util.db_connection import DBConnection
from exception.sis_exception import *
from models.student import Student
from models.teacher import Teacher
from models.course import Course
from models.enrollment import Enrollment
from models.payment import Payment
import pyodbc
from typing import List

class SISDaoImpl(SISDaoInterface):
    def __init__(self):
        self.conn = DBConnection.get_connection()
        self.cursor = self.conn.cursor()

    def add_student(self, student: Student) -> bool:
        try:
            query = """
                INSERT INTO Students (student_id, first_name, last_name, dob, email, phone)
                VALUES (?, ?, ?, ?, ?, ?)
            """
            self.cursor.execute(query, (
                student.student_id, student.first_name, student.last_name,
                student.dob, student.email, student.phone
            ))
            self.conn.commit()
            return True
        except pyodbc.IntegrityError:
            raise DuplicateEntryException("Student exists")
        except Exception as e:
            raise StudentDAOException(str(e))

    def get_student(self, student_id: int) -> Student:
        try:
            query = "SELECT * FROM Students WHERE student_id = ?"
            self.cursor.execute(query, (student_id,))
            row = self.cursor.fetchone()
            if not row:
                raise StudentNotFoundException()
            return Student(*row)
        except Exception as e:
            raise StudentDAOException(str(e))

    def add_teacher(self, teacher: Teacher) -> bool:
        try:
            query = """
                INSERT INTO Teachers (teacher_id, first_name, last_name, email)
                VALUES (?, ?, ?, ?)
            """
            self.cursor.execute(query, (
                teacher.teacher_id, teacher.first_name,
                teacher.last_name, teacher.email
            ))
            self.conn.commit()
            return True
        except Exception as e:
            raise TeacherDAOException(str(e))

    def get_teacher(self, teacher_id: int) -> Teacher:
        try:
            query = "SELECT * FROM Teachers WHERE teacher_id = ?"
            self.cursor.execute(query, (teacher_id,))
            row = self.cursor.fetchone()
            if not row:
                raise TeacherNotFoundException()
            return Teacher(*row)
        except Exception as e:
            raise TeacherDAOException(str(e))

    def add_course(self, course: Course) -> bool:
        try:
            query = """
                INSERT INTO Courses (course_id, name, code, credits, teacher_id)
                VALUES (?, ?, ?, ?, ?)
            """
            teacher_id = course.instructor.teacher_id if course.instructor else None
            self.cursor.execute(query, (
                course.course_id, course.name, course.code,
                course.credits, teacher_id
            ))
            self.conn.commit()
            return True
        except Exception as e:
            raise CourseDAOException(str(e))

    def get_course(self, course_id: int) -> Course:
        try:
            query = "SELECT * FROM Courses WHERE course_id = ?"
            self.cursor.execute(query, (course_id,))
            row = self.cursor.fetchone()
            if not row:
                raise CourseNotFoundException()
            
            teacher = None
            if row[4]:  # teacher_id exists
                teacher = self.get_teacher(row[4])
            
            return Course(
                course_id=row[0],
                name=row[1],
                code=row[2],
                credits=row[3],
                instructor=teacher
            )
        except Exception as e:
            raise CourseDAOException(str(e))

    def enroll_student(self, enrollment: Enrollment) -> bool:
        try:
            # Check for existing enrollment
            query = """
                SELECT 1 FROM Enrollments 
                WHERE student_id = ? AND course_id = ?
            """
            self.cursor.execute(query, (
                enrollment.student.student_id,
                enrollment.course.course_id
            ))
            if self.cursor.fetchone():
                raise DuplicateEnrollmentException()

            # Insert new enrollment
            query = """
                INSERT INTO Enrollments (enrollment_id, student_id, course_id, date)
                VALUES (?, ?, ?, ?)
            """
            self.cursor.execute(query, (
                enrollment.enrollment_id,
                enrollment.student.student_id,
                enrollment.course.course_id,
                enrollment.date
            ))
            self.conn.commit()
            return True
        except Exception as e:
            raise EnrollmentDAOException(str(e))

    def get_enrollments_by_student(self, student_id: int) -> List[Enrollment]:
        try:
            query = """
                SELECT e.enrollment_id, e.course_id, e.date,
                       c.name, c.code, c.credits
                FROM Enrollments e
                JOIN Courses c ON e.course_id = c.course_id
                WHERE e.student_id = ?
            """
            self.cursor.execute(query, (student_id,))
            enrollments = []
            for row in self.cursor.fetchall():
                course = Course(
                    course_id=row[1],
                    name=row[3],
                    code=row[4],
                    credits=row[5]
                )
                enrollments.append(Enrollment(
                    enrollment_id=row[0],
                    student=self.get_student(student_id),
                    course=course,
                    date=row[2]
                ))
            return enrollments
        except Exception as e:
            raise EnrollmentDAOException(str(e))

    def get_enrollments_by_course(self, course_id: int) -> List[Enrollment]:
        try:
            query = """
                SELECT e.enrollment_id, e.student_id, e.date,
                       s.first_name, s.last_name
                FROM Enrollments e
                JOIN Students s ON e.student_id = s.student_id
                WHERE e.course_id = ?
            """
            self.cursor.execute(query, (course_id,))
            enrollments = []
            for row in self.cursor.fetchall():
                student = Student(
                    student_id=row[1],
                    first_name=row[3],
                    last_name=row[4],
                    dob=None, email=None, phone=None
                )
                enrollments.append(Enrollment(
                    enrollment_id=row[0],
                    student=student,
                    course=self.get_course(course_id),
                    date=row[2]
                ))
            return enrollments
        except Exception as e:
            raise EnrollmentDAOException(str(e))

    def record_payment(self, payment: Payment) -> bool:
        try:
            if payment.amount <= 0:
                raise PaymentValidationException("Invalid amount")

            query = """
                INSERT INTO Payments (payment_id, student_id, amount, payment_date)
                VALUES (?, ?, ?, ?)
            """
            self.cursor.execute(query, (
                payment.payment_id,
                payment.student.student_id,
                payment.amount,
                payment.payment_date
            ))
            self.conn.commit()
            return True
        except Exception as e:
            raise PaymentDAOException(str(e))

    def get_payments_by_student(self, student_id: int) -> List[Payment]:
        try:
            query = """
                SELECT payment_id, amount, payment_date
                FROM Payments
                WHERE student_id = ?
                ORDER BY payment_date DESC
            """
            self.cursor.execute(query, (student_id,))
            return [
                Payment(
                    payment_id=row[0],
                    student=self.get_student(student_id),
                    amount=row[1],
                    payment_date=row[2]
                ) for row in self.cursor.fetchall()
            ]
        except Exception as e:
            raise PaymentDAOException(str(e))

    def update_course_teacher(self, course_id: int, teacher_id: int) -> bool:
        try:
            query = "UPDATE Courses SET teacher_id = ? WHERE course_id = ?"
            self.cursor.execute(query, (teacher_id, course_id))
            self.conn.commit()
            return True
        except Exception as e:
            raise CourseDAOException(str(e))

    def close_connection(self):
        try:
            if self.conn:
                self.conn.close()
        except Exception as e:
            print(f"Error closing connection: {str(e)}")