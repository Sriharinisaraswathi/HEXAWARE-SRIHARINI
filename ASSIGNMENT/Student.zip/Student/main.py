# main.py
from dao.sis_dao_impl import SISDaoImpl
from models.student import Student
from models.teacher import Teacher
from models.course import Course
from models.enrollment import Enrollment
from models.payment import Payment
from datetime import datetime
from exception.sis_exception import *

def display_menu():
    print("\n=== Student Information System ===")
    print("1. Add New Student")
    print("2. Enroll Student in Course")
    print("3. Assign Teacher to Course")
    print("4. Record Payment")
    print("5. Generate Enrollment Report")
    print("6. Generate Payment Report")
    print("7. Exit")
    return input("Enter your choice (1-7): ")

def main():
    sis_dao = SISDaoImpl()
    
    try:
        while True:
            choice = display_menu()
            
            if choice == '1':
                # Add new student
                print("\n--- Add New Student ---")
                student = Student(
                    student_id=int(input("Student ID: ")),
                    first_name=input("First Name: "),
                    last_name=input("Last Name: "),
                    dob=input("Date of Birth (YYYY-MM-DD): "),
                    email=input("Email: "),
                    phone=input("Phone Number: ")
                )
                if sis_dao.add_student(student):  # Changed from insert_student to add_student
                    print(f"\nSuccess: Added student {student.first_name} {student.last_name}")
                
            elif choice == '2':
                # Enroll student in course
                print("\n--- Enroll Student in Course ---")
                student_id = int(input("Student ID: "))
                course_id = int(input("Course ID: "))
                enrollment_date = datetime.now().strftime("%Y-%m-%d")
                
                student = sis_dao.get_student(student_id)
                course = sis_dao.get_course(course_id)
                
                enrollment = Enrollment(
                    enrollment_id=None,  # Let DB auto-generate
                    student=student,
                    course=course,
                    date=enrollment_date
                )
                
                if sis_dao.enroll_student(enrollment):  # Changed from insert_enrollment to enroll_student
                    print(f"\nSuccess: Enrolled {student.first_name} in {course.name}")
                
            elif choice == '3':
                # Assign teacher to course
                print("\n--- Assign Teacher to Course ---")
                teacher_id = int(input("Teacher ID: "))
                course_id = int(input("Course ID: "))
                
                teacher = sis_dao.get_teacher(teacher_id)
                course = sis_dao.get_course(course_id)
                
                if sis_dao.update_course_teacher(course_id, teacher_id):
                    print(f"\nSuccess: Assigned {teacher.first_name} to {course.name}")
                
            elif choice == '4':
                # Record payment
                print("\n--- Record Payment ---")
                student_id = int(input("Student ID: "))
                amount = float(input("Amount: "))
                payment_date = datetime.now().strftime("%Y-%m-%d")
                
                student = sis_dao.get_student(student_id)
                payment = Payment(
                    payment_id=None,  # Let DB auto-generate
                    student=student,
                    amount=amount,
                    payment_date=payment_date
                )
                
                if sis_dao.record_payment(payment):  # Changed from insert_payment to record_payment
                    print(f"\nSuccess: Recorded payment of ₹{amount} for {student.first_name}")
                
            elif choice == '5':
                # Generate enrollment report
                print("\n--- Enrollment Report ---")
                course_id = int(input("Course ID: "))
                course = sis_dao.get_course(course_id)
                enrollments = sis_dao.get_enrollments_by_course(course_id)
                
                print(f"\nEnrollment Report for {course.name}")
                print(f"Total Enrollments: {len(enrollments)}")
                for enrollment in enrollments:
                    print(f"- {enrollment.student.first_name} {enrollment.student.last_name} (ID: {enrollment.student.student_id})")
                
            elif choice == '6':
                # Generate payment report
                print("\n--- Payment Report ---")
                student_id = int(input("Student ID: "))
                student = sis_dao.get_student(student_id)
                payments = sis_dao.get_payments_by_student(student_id)
                
                print(f"\nPayment Report for {student.first_name} {student.last_name}")
                print(f"Total Payments: {len(payments)}")
                total = sum(p.amount for p in payments)
                for payment in payments:
                    print(f"- ₹{payment.amount} on {payment.payment_date}")
                print(f"Total Amount Paid: ₹{total}")
                
            elif choice == '7':
                print("\nExiting the system...")
                break
                
            else:
                print("\nInvalid choice. Please try again.")
                
    except StudentNotFoundException as e:
        print(f"\nError: Student not found - {str(e)}")
    except TeacherNotFoundException as e:
        print(f"\nError: Teacher not found - {str(e)}")
    except CourseNotFoundException as e:
        print(f"\nError: Course not found - {str(e)}")
    except DuplicateEnrollmentException as e:
        print(f"\nError: {str(e)}")
    except PaymentValidationException as e:
        print(f"\nError: {str(e)}")
    except SISException as e:
        print(f"\nSystem Error: {str(e)}")
    except Exception as e:
        print(f"\nUnexpected error: {str(e)}")
    finally:
        sis_dao.close_connection()
        print("\nDatabase connection closed")

if __name__ == "__main__":  # Fixed from "_main_" to "__main__"
    main()