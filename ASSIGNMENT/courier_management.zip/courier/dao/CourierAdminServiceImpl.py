from dao.CourierUserServiceImpl import CourierUserServiceImpl
from services.ICourierAdminService import ICourierAdminService

class CourierAdminServiceImpl(CourierUserServiceImpl, ICourierAdminService):
    def __init__(self, companyObj):
        super().__init__(companyObj)

    def addCourierStaff(self, employeeObj):
        self.companyObj.getEmployeeDetails().append(employeeObj)
        return employeeObj.getEmployeeID()
