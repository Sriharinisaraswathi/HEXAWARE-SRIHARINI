from services.ICourierUserService import ICourierUserService

class CourierUserServiceCollectionImpl(ICourierUserService):
    def __init__(self, companyObj):
        self.companyObj = companyObj  # CourierCompanyCollection object

    # Implement methods here using list operations
    def placeOrder(self, courierObj):
        self.companyObj.getCourierDetails().append(courierObj)
        return courierObj.getTrackingNumber()
