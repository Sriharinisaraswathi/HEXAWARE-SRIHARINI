from dao.CourierUserServiceCollectionImpl import CourierUserServiceCollectionImpl
from services.ICourierAdminService import ICourierAdminService

class CourierAdminServiceCollectionImpl(CourierUserServiceCollectionImpl, ICourierAdminService):
    def __init__(self, companyObj):
        super().__init__(companyObj)

    def addCourierStaff(self, employeeObj):
        self.companyObj.getEmployeeDetails().append(employeeObj)
        return employeeObj.getEmployeeID()
