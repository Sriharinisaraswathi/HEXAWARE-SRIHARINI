from connectionutil.db_connection import DBConnection
from exceptions.TrackingNumberNotFoundException import TrackingNumberNotFoundException
from exceptions.InvalidEmployeeIdException import InvalidEmployeeIdException
from datetime import datetime
import random

class CourierServiceDb:
    connection = None

    def __init__(self):
        CourierServiceDb.connection = DBConnection.get_connection()

    def create_user(self, user_name, email, password, contact_number, address):
        cursor = self.connection.cursor()
        query = """INSERT INTO Users (UserName, Email, Password, ContactNumber, Address)
                   VALUES (?, ?, ?, ?, ?)"""
        cursor.execute(query, (user_name, email, password, contact_number, address))
        self.connection.commit()
        
        # Get the newly created user's ID
        cursor.execute("SELECT @@IDENTITY")
        user_id = cursor.fetchone()[0]
        print("✔ User created successfully.")
        return user_id

    def generate_tracking_number(self):
        cursor = self.connection.cursor()
        while True:
            # Generate a random tracking number
            tracking = f"TN{random.randint(10000, 99999)}"
            # Check if it exists
            cursor.execute("SELECT COUNT(*) FROM Couriers WHERE TrackingNumber = ?", (tracking,))
            if cursor.fetchone()[0] == 0:
                return tracking

    # 1️⃣ Insert new order
    def place_order(self, sender, sender_addr, receiver, receiver_addr, weight, status, tracking, delivery_date, user_id):
        cursor = self.connection.cursor()
        # Generate a unique tracking number instead of using the passed one
        unique_tracking = self.generate_tracking_number()
        query = """INSERT INTO Couriers (SenderName, SenderAddress, ReceiverName, ReceiverAddress, 
                    Weight, Status, TrackingNumber, DeliveryDate, UserID)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)"""
        cursor.execute(query, (sender, sender_addr, receiver, receiver_addr, weight, status, unique_tracking, delivery_date, user_id))
        self.connection.commit()
        print(f" Order placed successfully. Tracking number: {unique_tracking}")
        return unique_tracking

    # 2️⃣ Update courier status
    def update_courier_status(self, tracking_number, new_status):
        cursor = self.connection.cursor()
        query = "UPDATE Couriers SET Status = ? WHERE TrackingNumber = ?"
        cursor.execute(query, (new_status, tracking_number))
        self.connection.commit()
        print("Status updated.")

    # 3️⃣ Retrieve delivery history for a parcel
    def get_delivery_history(self, tracking_number):
        cursor = self.connection.cursor()
        query = "SELECT * FROM Couriers WHERE TrackingNumber = ?"
        cursor.execute(query, (tracking_number,))
        result = cursor.fetchone()
        if result:
            print("Delivery History:")
            print(result)
        else:
            print(" No courier found with that tracking number.")

    # 4️⃣ Generate shipment status report
    def shipment_status_report(self):
        cursor = self.connection.cursor()
        query = "SELECT Status, COUNT(*) as Count FROM Couriers GROUP BY Status"
        cursor.execute(query)
        results = cursor.fetchall()
        print("\n Shipment Status Report:")
        for row in results:
            print(f"{row.Status} : {row.Count}")

    # 5️⃣ Generate revenue report
    def revenue_report(self):
        cursor = self.connection.cursor()
        query = "SELECT SUM(Amount) as TotalRevenue FROM Payments"
        cursor.execute(query)
        result = cursor.fetchone()
        print(f"\nTotal Revenue: ₹{result.TotalRevenue if result.TotalRevenue else 0:.2f}")

    def get_order_status(self, tracking_number):
        cursor = self.connection.cursor()
        query = "SELECT Status FROM Couriers WHERE TrackingNumber = ?"
        cursor.execute(query, (tracking_number,))
        result = cursor.fetchone()
        if not result:
            raise TrackingNumberNotFoundException()
        return result.Status

    def cancel_order(self, tracking_number):
        cursor = self.connection.cursor()
        query = "UPDATE Couriers SET Status = 'Cancelled' WHERE TrackingNumber = ?"
        cursor.execute(query, (tracking_number,))
        if cursor.rowcount == 0:
            raise TrackingNumberNotFoundException()
        self.connection.commit()
        return True

    def get_assigned_orders(self, employee_id):
        cursor = self.connection.cursor()
        query = """SELECT * FROM Couriers c 
                  JOIN CourierAssignments ca ON c.CourierID = ca.CourierID 
                  WHERE ca.EmployeeID = ?"""
        cursor.execute(query, (employee_id,))
        results = cursor.fetchall()
        if not results:
            raise InvalidEmployeeIdException()
        return results

    def add_courier_staff(self, employee):
        cursor = self.connection.cursor()
        query = """INSERT INTO Employees (EmployeeName, Email, ContactNumber, Role, Salary)
                   VALUES (?, ?, ?, ?, ?)"""
        cursor.execute(query, (
            employee.get_employeeName(),
            employee.get_email(),
            employee.get_contactNumber(),
            employee.get_role(),
            employee.get_salary()
        ))
        self.connection.commit()
        
        cursor.execute("SELECT @@IDENTITY")
        return cursor.fetchone()[0]

