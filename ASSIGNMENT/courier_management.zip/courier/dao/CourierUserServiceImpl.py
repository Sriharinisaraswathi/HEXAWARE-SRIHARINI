from services.ICourierUserService import ICourierUserService

class CourierUserServiceImpl(ICourierUserService):
    def __init__(self, companyObj):
        self.companyObj = companyObj

    # Implement interface methods using companyObj.courierDetails (array of objects)
    # Example:
    def placeOrder(self, courierObj):
        self.companyObj.getCourierDetails().append(courierObj)
        return courierObj.getTrackingNumber()
