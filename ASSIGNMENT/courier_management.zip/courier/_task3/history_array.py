tracking_history = ["Chennai Hub", "Bangalore Hub", "In Transit", "Out for Delivery", "Delivered"]

for update in tracking_history:
    print(update)
