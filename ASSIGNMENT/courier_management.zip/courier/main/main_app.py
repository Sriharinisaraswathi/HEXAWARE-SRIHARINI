from dao.courier_service_db import CourierServiceDb

service = CourierServiceDb()

# First create a user
user_id = service.create_user("Harini", "harini@email.com", "password123", "1234567890", "Chennai")

# Place a new order with the created user's ID - note we removed the hardcoded tracking number
tracking_number = service.place_order("Harini", "Chennai", "Krishna", "Bangalore", 3.5, "In Transit", None, "2025-04-26", user_id)

# Update courier status using the returned tracking number
service.update_courier_status(tracking_number, "Delivered")

# Get delivery history
service.get_delivery_history(tracking_number)

# Generate shipment status report
service.shipment_status_report()

# Generate revenue report
service.revenue_report()
