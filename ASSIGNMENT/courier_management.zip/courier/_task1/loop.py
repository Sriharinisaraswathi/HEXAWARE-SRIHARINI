couriers = {"Ram": 2, "Raj": 4, "Sara": 1}  
max_capacity = 5

for name, load in couriers.items():
    if load < max_capacity:
        print(f"Assigning courier {name}")
        couriers[name] += 1
        break
else:
    print("No available courier.")
