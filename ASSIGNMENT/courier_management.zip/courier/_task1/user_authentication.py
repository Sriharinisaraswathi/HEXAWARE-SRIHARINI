username = input("Enter username: ")
password = input("Enter password: ")

if username == "employee" and password == "emp123":
    print("Employee Login Successful")
elif username == "customer" and password == "cust123":
    print("Customer Login Successful")
else:
    print("Invalid credentials.")
