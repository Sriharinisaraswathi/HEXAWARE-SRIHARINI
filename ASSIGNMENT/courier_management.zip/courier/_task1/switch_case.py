weight = float(input("Enter parcel weight in kg: "))

match weight:
    case w if w < 2:
        print("Light Parcel")
    case w if 2 <= w < 5:
        print("Medium Parcel")
    case _:
        print("Heavy Parcel")
