status = input("Enter order status (Processing/Delivered/Cancelled): ")

if status == "Delivered":
    print("Order has been delivered.")
elif status == "Processing":
    print("Order is still being processed.")
elif status == "Cancelled":
    print("Order has been cancelled.")
else:
    print("Invalid status entered.")
