def calculate_shipping_cost(source, destination, weight):
    distance = 500 if source != destination else 100
    cost_per_kg = 10
    total = distance * cost_per_kg * weight / 100
    return total

print("Shipping cost: ₹", calculate_shipping_cost("Chennai", "Bangalore", 5))
