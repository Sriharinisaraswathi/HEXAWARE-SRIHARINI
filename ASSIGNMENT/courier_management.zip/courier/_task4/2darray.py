tracking_data = [
    ["TN101", "In Transit"],
    ["TN102", "Out for Delivery"],
    ["TN103", "Delivered"]
]

tracking_no = input("Enter tracking number: ")

for data in tracking_data:
    if data[0] == tracking_no:
        print(f"Status: {data[1]}")
        break
else:
    print("Tracking number not found.")
