def format_address(street, city, state, zip_code):
    street = street.title()
    city = city.title()
    state = state.title()
    zip_code = zip_code.zfill(6)
    return f"{street}, {city}, {state} - {zip_code}"

print(format_address("no 7 park road", "chennai", "tamil nadu", "6001"))
