def generate_email(name, order_no, address, delivery_date):
    return f"""
    Dear {name},

    Your order {order_no} has been confirmed.
    Delivery Address: {address}
    Expected Delivery Date: {delivery_date}

    Thank you for choosing our service!
    """

print(generate_email("Harini", "TN101", "Chennai, Tamil Nadu", "2025-04-26"))
