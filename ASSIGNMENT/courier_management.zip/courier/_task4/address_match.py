def find_similar_addresses(addresses, keyword):
    for address in addresses:
        if keyword.lower() in address.lower():
            print(f"Similar Address: {address}")

address_list = ["No.7 Park Road Chennai", "5 Garden Street Bangalore", "Park Avenue Mumbai"]
find_similar_addresses(address_list, "Park")
