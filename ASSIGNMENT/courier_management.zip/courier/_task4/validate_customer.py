def validate_customer_data(data, detail):
    if detail == "name":
        if data.isalpha() and data.istitle():
            return True
    elif detail == "address":
        if data.replace(" ", "").isalnum():
            return True
    elif detail == "phone":
        if len(data) == 12 and data[3] == '-' and data[7] == '-' and data.replace("-", "").isdigit():
            return True
    return False

print(validate_customer_data("Harini", "name"))
print(validate_customer_data("No.7 Park Road", "address"))
print(validate_customer_data("123-456-7890", "phone"))
