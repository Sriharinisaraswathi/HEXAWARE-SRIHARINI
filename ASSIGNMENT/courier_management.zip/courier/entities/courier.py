class Courier:
    def __init__(self, courierID=None, senderName=None, senderAddress=None, receiverName=None, receiverAddress=None, weight=None, status=None, trackingNumber=None, deliveryDate=None, userID=None):
        self.__courierID = courierID
        self.__senderName = senderName
        self.__senderAddress = senderAddress
        self.__receiverName = receiverName
        self.__receiverAddress = receiverAddress
        self.__weight = weight
        self.__status = status
        self.__trackingNumber = trackingNumber
        self.__deliveryDate = deliveryDate
        self.__userID = userID

    def get_courierID(self): return self.__courierID
    def set_courierID(self, courierID): self.__courierID = courierID

    def get_senderName(self): return self.__senderName
    def set_senderName(self, senderName): self.__senderName = senderName

    def get_senderAddress(self): return self.__senderAddress
    def set_senderAddress(self, senderAddress): self.__senderAddress = senderAddress

    def get_receiverName(self): return self.__receiverName
    def set_receiverName(self, receiverName): self.__receiverName = receiverName

    def get_receiverAddress(self): return self.__receiverAddress
    def set_receiverAddress(self, receiverAddress): self.__receiverAddress = receiverAddress

    def get_weight(self): return self.__weight
    def set_weight(self, weight): self.__weight = weight

    def get_status(self): return self.__status
    def set_status(self, status): self.__status = status

    def get_trackingNumber(self): return self.__trackingNumber
    def set_trackingNumber(self, trackingNumber): self.__trackingNumber = trackingNumber

    def get_deliveryDate(self): return self.__deliveryDate
    def set_deliveryDate(self, deliveryDate): self.__deliveryDate = deliveryDate

    def get_userID(self): return self.__userID
    def set_userID(self, userID): self.__userID = userID

    def __str__(self):
        return f"Courier [courierID={self.__courierID}, senderName={self.__senderName}, receiverName={self.__receiverName}, weight={self.__weight}, status={self.__status}, trackingNumber={self.__trackingNumber}]"
