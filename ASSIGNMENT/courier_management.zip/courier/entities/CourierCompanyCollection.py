from entities.courier import Courier
from entities.employee import Employee
from entities.location import Location

class CourierCompanyCollection:
    def __init__(self, companyName):
        self.__companyName = companyName
        self.__courierDetails = []  # list of Courier objects
        self.__employeeDetails = [] # list of Employee objects
        self.__locationDetails = [] # list of Location objects

    # Getters and Setters
    def getCompanyName(self):
        return self.__companyName

    def setCompanyName(self, name):
        self.__companyName = name

    def getCourierDetails(self):
        return self.__courierDetails

    def getEmployeeDetails(self):
        return self.__employeeDetails

    def getLocationDetails(self):
        return self.__locationDetails

    def __str__(self):
        return f"CourierCompanyCollection({self.__companyName})"
