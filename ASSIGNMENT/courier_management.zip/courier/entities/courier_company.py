class CourierCompany:
    def __init__(self, companyName=None):
        self.__companyName = companyName
        self.__courierDetails = []
        self.__employeeDetails = []
        self.__locationDetails = []

    def addCourier(self, courier):
        self.__courierDetails.append(courier)

    def addEmployee(self, employee):
        self.__employeeDetails.append(employee)

    def addLocation(self, location):
        self.__locationDetails.append(location)

    def __str__(self):
        return f"Company: {self.__companyName}, Couriers: {len(self.__courierDetails)}, Employees: {len(self.__employeeDetails)}"
