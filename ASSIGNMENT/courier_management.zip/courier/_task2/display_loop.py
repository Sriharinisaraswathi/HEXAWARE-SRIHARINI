orders = ["ORD101", "ORD102", "ORD103"]
customer_name = input("Enter customer name: ")

print(f"Orders for {customer_name}:")
for order in orders:
    print(order)
