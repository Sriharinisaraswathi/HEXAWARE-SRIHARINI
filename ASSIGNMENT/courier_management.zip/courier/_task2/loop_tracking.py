location = "Warehouse"

while location != "Delivered":
    print(f"Current Location: {location}")
    location = input("Enter next location: ")

print("Parcel Delivered!")
