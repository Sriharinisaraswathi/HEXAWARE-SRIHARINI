import pyodbc

class DBConnection:
    connection = None

    @staticmethod
    def get_connection():
        if DBConnection.connection is None:
            props = {}
            with open('connectionutil/db.properties', 'r') as f:
                for line in f:
                    if '=' in line:
                        key, value = line.strip().split('=', 1)
                        props[key.strip()] = value.strip()

            conn_str = (
                f"DRIVER={props['driver']};"
                f"SERVER={props['server']};"
                f"DATABASE={props['database']};"
                f"Trusted_Connection={props['trusted_connection']};"
            )

            DBConnection.connection = pyodbc.connect(conn_str)
        return DBConnection.connection
