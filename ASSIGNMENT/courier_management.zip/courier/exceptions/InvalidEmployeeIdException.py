class InvalidEmployeeIdException(Exception):
    def __init__(self, message="Invalid employee ID entered."):
        super().__init__(message)
