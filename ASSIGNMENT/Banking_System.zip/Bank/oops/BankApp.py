from abc import ABC, abstractmethod
import re
from collections import defaultdict
from typing import Optional  # Import for type hinting

# Custom Exceptions
class InsufficientFundException(Exception):
    pass

class InvalidAccountException(Exception):
    pass

class OverDraftLimitExceededException(Exception):
    pass

# Abstract Classes
class ICustomerServiceProvider(ABC):
    @abstractmethod
    def get_account_balance(self, account_number):
        pass

    @abstractmethod
    def deposit(self, account_number, amount):
        pass

    @abstractmethod
    def withdraw(self, account_number, amount):
        pass

    @abstractmethod
    def transfer(self, from_account_number, to_account_number, amount):
        pass

    @abstractmethod
    def get_account_details(self, account_number):
        pass


class IBankServiceProvider(ABC):
    @abstractmethod
    def create_account(self, customer, account_type, initial_balance):
        pass

    @abstractmethod
    def list_accounts(self):
        pass

    @abstractmethod
    def calculate_interest(self):
        pass


# Customer Class
class Customer:
    def __init__(self, customer_id=None, first_name=None, last_name=None, email=None, phone=None, address=None):
        self.customer_id = customer_id
        self.first_name = first_name
        self.last_name = last_name
        self.email = email
        self.phone = phone
        self.address = address

    def set_email(self, email):
        if re.match(r"[^@]+@[^@]+\.[^@]+", email):
            self.email = email
        else:
            raise ValueError("Invalid email address")

    def set_phone(self, phone):
        if re.match(r"^\d{10}$", phone):
            self.phone = phone
        else:
            raise ValueError("Invalid phone number")

    def print_customer_info(self):
        print(f"Customer ID: {self.customer_id}")
        print(f"First Name: {self.first_name}")
        print(f"Last Name: {self.last_name}")
        print(f"Email: {self.email}")
        print(f"Phone: {self.phone}")
        print(f"Address: {self.address}")


# Account Classes
class Account:
    last_acc_no = 1000

    def __init__(self, account_type, balance, customer):
        Account.last_acc_no += 1
        self.account_number = Account.last_acc_no
        self.account_type = account_type
        self.balance = balance
        self.customer = customer

    def deposit(self, amount):
        if amount > 0:
            self.balance += amount
        else:
            raise ValueError("Invalid deposit amount")

    def withdraw(self, amount):
        if amount > 0 and amount <= self.balance:
            self.balance -= amount
        else:
            raise ValueError("Invalid withdrawal amount or insufficient balance")

    def print_account_info(self):
        print(f"Account Number: {self.account_number}")
        print(f"Account Type: {self.account_type}")
        print(f"Balance: {self.balance}")
        self.customer.print_customer_info()


class SavingsAccount(Account):
    MIN_BALANCE = 500

    def __init__(self, balance, customer):
        if balance < self.MIN_BALANCE:
            raise ValueError("Minimum balance for Savings Account is 500")
        super().__init__("Savings", balance, customer)

    def calculate_interest(self):
        interest_rate = 0.045
        return self.balance * interest_rate


class CurrentAccount(Account):
    OVERDRAFT_LIMIT = 5000

    def __init__(self, balance, customer):
        super().__init__("Current", balance, customer)

    def withdraw(self, amount):
        if amount > 0 and amount <= self.balance + self.OVERDRAFT_LIMIT:
            self.balance -= amount
        else:
            raise ValueError("Invalid withdrawal amount or exceeds overdraft limit")


class ZeroBalanceAccount(Account):
    def __init__(self, customer):
        super().__init__("Zero Balance", 0, customer)


# Service Provider Implementations
class CustomerServiceProviderImpl(ICustomerServiceProvider):
    def __init__(self):
        self.accounts = defaultdict(dict)  # Using HashMap (dictionary)

    def get_account_balance(self, account_number):
        account = self.accounts.get(account_number)
        if account:
            return account.balance
        else:
            raise InvalidAccountException("Account not found")

    def deposit(self, account_number, amount):
        account = self.accounts.get(account_number)
        if account:
            account.deposit(amount)
            return account.balance
        else:
            raise InvalidAccountException("Account not found")

    def withdraw(self, account_number, amount):
        account = self.accounts.get(account_number)
        if account:
            try:
                account.withdraw(amount)
            except ValueError:
                if isinstance(account, CurrentAccount):
                    raise OverDraftLimitExceededException("Overdraft limit exceeded")
                else:
                    raise InsufficientFundException("Insufficient funds")
            return account.balance
        else:
            raise InvalidAccountException("Account not found")

    def transfer(self, from_account_number, to_account_number, amount):
        from_account = self.accounts.get(from_account_number)
        to_account = self.accounts.get(to_account_number)
        if from_account and to_account:
            try:
                from_account.withdraw(amount)
                to_account.deposit(amount)
            except ValueError:
                raise InsufficientFundException("Insufficient funds for transfer")
        else:
            raise InvalidAccountException("One or both accounts not found")

    def get_account_details(self, account_number):
        account = self.accounts.get(account_number)
        if account:
            account.print_account_info()
        else:
            raise InvalidAccountException("Account not found")


class BankServiceProviderImpl(CustomerServiceProviderImpl, IBankServiceProvider):
    def __init__(self, branch_name, branch_address):
        super().__init__()
        self.branch_name = branch_name
        self.branch_address = branch_address
        self.customers_db = {}  # Simulated in-memory database for customers
        self.accounts_db = {}   # Simulated in-memory database for accounts

    # Overloaded method for account creation
    def create_account(self, customer, account_type, initial_balance: Optional[float] = None):
        if customer.customer_id not in self.customers_db:
            self.customers_db[customer.customer_id] = customer  # Save customer to database

        if account_type == "Savings":
            account = SavingsAccount(initial_balance or 500, customer)
        elif account_type == "Current":
            account = CurrentAccount(initial_balance or 0, customer)
        elif account_type == "Zero Balance":
            account = ZeroBalanceAccount(customer)
        else:
            raise ValueError("Invalid account type")

        self.accounts[account.account_number] = account
        self.accounts_db[account.account_number] = account  # Save account to database
        return account

    def list_accounts(self):
        sorted_accounts = sorted(self.accounts.values(), key=lambda acc: acc.customer.first_name)
        for account in sorted_accounts:
            account.print_account_info()

    def calculate_interest(self):
        for account in self.accounts.values():
            if isinstance(account, SavingsAccount):
                interest = account.calculate_interest()
                account.deposit(interest)

    # New method to retrieve all customers from the database
    def list_customers(self):
        for customer_id, customer in self.customers_db.items():
            print(f"Customer ID: {customer_id}")
            customer.print_customer_info()


# BankApp Class
class BankApp:
    def __init__(self):
        self.bank = BankServiceProviderImpl("Main Branch", "123 Bank Street")

    def run(self):
        while True:
            try:
                print("\nBanking System Menu:")
                print("1. Create Account")
                print("2. Deposit")
                print("3. Withdraw")
                print("4. Transfer")
                print("5. Get Account Balance")
                print("6. Get Account Details")
                print("7. List Accounts")
                print("8. List Customers")  # New menu option
                print("9. Exit")
                choice = int(input("Enter your choice: "))

                if choice == 1:
                    customer_id = input("Enter Customer ID: ")
                    first_name = input("Enter First Name: ")
                    last_name = input("Enter Last Name: ")
                    email = input("Enter Email: ")
                    phone = input("Enter Phone: ")
                    address = input("Enter Address: ")
                    customer = Customer(customer_id, first_name, last_name, email, phone, address)

                    print("\n1. Savings Account")
                    print("2. Current Account")
                    print("3. Zero Balance Account")
                    account_choice = int(input("Enter account type: "))
                    account_type = "Savings" if account_choice == 1 else "Current" if account_choice == 2 else "Zero Balance"
                    initial_balance = None
                    if account_type != "Zero Balance":
                        initial_balance = float(input("Enter initial balance: "))
                    account = self.bank.create_account(customer, account_type, initial_balance)
                    print(f"Account created successfully! Account Number: {account.account_number}")

                elif choice == 2:
                    account_number = int(input("Enter Account Number: "))
                    amount = float(input("Enter amount to deposit: "))
                    balance = self.bank.deposit(account_number, amount)
                    print(f"Deposit successful! New Balance: {balance}")

                elif choice == 3:
                    account_number = int(input("Enter Account Number: "))
                    amount = float(input("Enter amount to withdraw: "))
                    balance = self.bank.withdraw(account_number, amount)
                    print(f"Withdrawal successful! New Balance: {balance}")

                elif choice == 4:
                    from_account = int(input("Enter From Account Number: "))
                    to_account = int(input("Enter To Account Number: "))
                    amount = float(input("Enter amount to transfer: "))
                    self.bank.transfer(from_account, to_account, amount)
                    print("Transfer successful!")

                elif choice == 5:
                    account_number = int(input("Enter Account Number: "))
                    balance = self.bank.get_account_balance(account_number)
                    print(f"Account Balance: {balance}")

                elif choice == 6:
                    account_number = int(input("Enter Account Number: "))
                    self.bank.get_account_details(account_number)

                elif choice == 7:
                    self.bank.list_accounts()

                elif choice == 8:  # New option to list customers
                    self.bank.list_customers()

                elif choice == 9:
                    print("Exiting...")
                    break

                else:
                    print("Invalid choice! Please try again.")

            except InvalidAccountException as e:
                print(f"Error: {e}")
            except InsufficientFundException as e:
                print(f"Error: {e}")
            except OverDraftLimitExceededException as e:
                print(f"Error: {e}")
            except ValueError as e:
                print(f"Error: {e}")
            except Exception as e:
                print(f"Unexpected error: {e}")

if __name__ == "__main__":
    app = BankApp()
    app.run()
