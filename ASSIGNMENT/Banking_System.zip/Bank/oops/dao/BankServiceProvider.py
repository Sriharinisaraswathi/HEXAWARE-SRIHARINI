from abc import ABC, abstractmethod
from oops.entity.Customer import Customer  # Updated to use oops package prefix

class IBankServiceProvider(ABC):
    @abstractmethod
    def create_account(self, account_number: int, customer_name: str, customer_address: str, phone: str, acc_type: str, balance: float):
        """Create a new bank account"""
        pass

    @abstractmethod
    def list_accounts(self):
        pass

    @abstractmethod
    def get_account_details(self, account_number: int):
        pass

    @abstractmethod
    def calculate_interest(self):
        pass
