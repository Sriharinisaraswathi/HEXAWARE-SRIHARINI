import pyodbc
from oops.dao.BankServiceProvider import IBankServiceProvider
from oops.entity.Customer import Customer
from oops.entity.Account import Account, SavingsAccount, CurrentAccount, ZeroBalanceAccount
from oops.entity.Balance import Balance
from oops.exceptions.BankException import BankException

class BankServiceImpl(IBankServiceProvider):
    def __init__(self, branch_name: str, branch_address: str):
        self.accounts = []  # Single list for accounts
        self.branch_name = branch_name
        self.branch_address = branch_address
        self.transaction_list = []
        self.connection = None
        self.cursor = None
        self.used_account_numbers = set()  # Track used account numbers

    def create_customer(self, customer):
        query = f"INSERT INTO Customers (customer_id, name, email) VALUES (?, ?, ?)"
        self.cursor.execute(query, (customer.customer_id, customer.name, customer.email))
        self.connection.commit()

    def create_account(self, account_number: int, customer_name: str, customer_address: str, phone: str, acc_type: str, balance: float):
        try:
            # Validate account number
            if account_number in self.used_account_numbers:
                raise BankException(f"Account number {account_number} already exists")
            if account_number < 1000:
                raise BankException("Account number must be at least 1000")
            
            # Create customer object
            customer_id = len(self.accounts) + 1
            customer = Customer(customer_id, customer_name, customer_address, phone)
            
            # Create appropriate account type and set account number
            if acc_type.lower() == "savings":
                new_account = SavingsAccount(customer, balance)
            elif acc_type.lower() == "current":
                new_account = CurrentAccount(customer, balance)
            elif acc_type.lower() == "zerobalance":
                new_account = ZeroBalanceAccount(customer)
            else:
                raise BankException(f"Invalid account type: {acc_type}")
            
            new_account.account_number = account_number
            self.used_account_numbers.add(account_number)
            self.accounts.append(new_account)
            return new_account
            
        except ValueError as ve:
            raise BankException(str(ve))
        except Exception as e:
            raise BankException(f"Error creating account: {str(e)}")

    def list_accounts(self):
        if not self.accounts:
            raise BankException("No accounts found in the system")
        
        account_list = []
        for account in self.accounts:
            account_info = (
                f"Account Number: {account.account_number}\n"
                f"Customer Name: {account.customer.name}\n"
                f"Account Type: {account.account_type}\n"
                f"Balance: ${account.balance:.2f}\n"
                f"------------------------"
            )
            account_list.append(account_info)
        return account_list

    def get_account_details(self, account_number: int):
        for account in self.accounts:
            if account.account_number == account_number:
                details = {
                    'Account Number': account.account_number,
                    'Customer Name': account.customer.name,
                    'Customer Address': account.customer.address,
                    'Phone': account.customer.phone,
                    'Account Type': account.account_type,
                    'Balance': f"${account.balance:.2f}"
                }
                return details
        raise BankException(f"Account with number {account_number} not found.")

    def calculate_interest(self):
        
        pass

    def get_balance(self, account_id):
        query = f"SELECT balance FROM Accounts WHERE account_id = ?"
        self.cursor.execute(query, (account_id,))
        balance = self.cursor.fetchone()
        return balance[0] if balance else None

    def deposit(self, account_id, amount):
        current_balance = self.get_balance(account_id)
        if current_balance is None:
            raise ValueError("Account not found")
        new_balance = current_balance + amount
        query = f"UPDATE Accounts SET balance = ? WHERE account_id = ?"
        self.cursor.execute(query, (new_balance, account_id))
        self.connection.commit()

    def withdraw(self, account_id, amount):
        current_balance = self.get_balance(account_id)
        if current_balance is None:
            raise ValueError("Account not found")
        if current_balance < amount:
            raise ValueError("Insufficient balance")
        new_balance = current_balance - amount
        query = f"UPDATE Accounts SET balance = ? WHERE account_id = ?"
        self.cursor.execute(query, (new_balance, account_id))
        self.connection.commit()
