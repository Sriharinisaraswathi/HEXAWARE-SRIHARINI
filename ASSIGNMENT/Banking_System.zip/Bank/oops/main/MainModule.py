from oops.dao.BankServiceImpl import BankServiceImpl
from oops.entity.Customer import Customer
from oops.exceptions.BankException import BankException

class MainModule:
    def __init__(self):
        self.bank_service = BankServiceImpl("Main Branch", "123 Bank Street")

    def main(self):
        while True:
            print("\nMenu:")
            print("1. Create Account")
            print("2. List Accounts")
            print("3. Get Account Details")
            print("4. Exit")
            choice = input("Enter your choice: ")

            try:
                if choice == "1":
                    print("\nCreate New Account")
                    print("-----------------")
                    account_number = int(input("Enter account number (minimum 1000): "))
                    name = input("Enter customer name: ")
                    address = input("Enter customer address: ")
                    phone = input("Enter customer phone: ")
                    print("\nAccount Types:")
                    print("1. Savings")
                    print("2. Current")
                    print("3. ZeroBalance")
                    acc_type = input("Choose account type (Savings/Current/ZeroBalance): ").strip()
                    
                    if acc_type.lower() == "zerobalance":
                        balance = 0
                    else:
                        balance = float(input("Enter initial balance: "))
                    
                    account = self.bank_service.create_account(account_number, name, address, phone, acc_type, balance)
                    print(f"\nAccount created successfully!")
                    print(f"Account Number: {account.account_number}")
                elif choice == "2":
                    accounts = self.bank_service.list_accounts()
                    for account in accounts:
                        print(account)
                elif choice == "3":
                    acc_number = int(input("Enter account number: "))
                    account = self.bank_service.get_account_details(acc_number)
                    print(account)
                elif choice == "4":
                    print("Exiting...")
                    break
                else:
                    print("Invalid choice. Please try again.")
            except BankException as e:
                print(f"Error: {e}")
            except Exception as e:
                print(f"An unexpected error occurred: {e}")

if __name__ == "__main__":
    app = MainModule()
    app.main()
