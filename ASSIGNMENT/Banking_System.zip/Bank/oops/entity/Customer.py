class Customer:
    def __init__(self, customer_id: int, name: str, address: str, phone: str):
        self.customer_id = customer_id
        self.name = name
        self.address = address
        self.phone = phone

    def __str__(self):
        return f"Customer[ID={self.customer_id}, Name={self.name}, Address={self.address}, Phone={self.phone}]"
