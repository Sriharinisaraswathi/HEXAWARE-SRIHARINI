from datetime import datetime
from .Account import Account

class Balance:
    def __init__(self, account_id, balance):
        self.account_id = account_id
        self.balance = balance

class Transaction:
    def __init__(self, account: Account, description: str, transaction_type: str, transaction_amount: float):
        self.account = account
        self.description = description
        self.date_time = datetime.now()
        self.transaction_type = transaction_type
        self.transaction_amount = transaction_amount

    def __str__(self):
        return f"Transaction[Account={self.account.account_number}, Type={self.transaction_type}, Amount={self.transaction_amount}, Date={self.date_time}]"
