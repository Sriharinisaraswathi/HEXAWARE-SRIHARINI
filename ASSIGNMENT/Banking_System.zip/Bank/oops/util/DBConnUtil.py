import pyodbc
import configparser
import sqlite3

class DBConnUtil:
    @staticmethod
    def get_connection():
        try:
            # Read the properties file
            config = configparser.ConfigParser()
            config.read('db.properties')

            server = config.get('Database', 'server')
            database = config.get('Database', 'database')
            authentication = config.get('Database', 'authentication')

            # Build connection string for Windows Authentication (no username, password required)
            if authentication == 'windows':
                conn_str = f'DRIVER={{ODBC Driver 17 for SQL Server}};SERVER={server};DATABASE={database};Trusted_Connection=yes;'

            # Establish and return connection
            conn = pyodbc.connect(conn_str)
            return conn
        except Exception as e:
            print(f"Error in getting DB connection: {e}")
            return None

    @staticmethod
    def get_db_conn():
        try:
            conn = sqlite3.connect("bank.db")
            return conn
        except sqlite3.Error as e:
            raise Exception(f"Database connection error: {e}")
