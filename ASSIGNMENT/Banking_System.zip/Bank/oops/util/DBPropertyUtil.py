import configparser

class DBPropertyUtil:
    @staticmethod
    def load_properties():
        try:
            config = configparser.ConfigParser()
            config.read('db.properties')

            # Return the properties as a dictionary
            db_config = {
                'server': config.get('Database', 'server'),
                'database': config.get('Database', 'database'),
                'authentication': config.get('Database', 'authentication')
            }
            return db_config
        except Exception as e:
            print(f"Error loading db.properties: {e}")
            return None
