

def atm_transaction():
    balance = float(input("Enter your current balance: "))

    while True:
        print("\n---- ATM Menu ----")
        print("1. Check Balance")
        print("2. Withdraw")
        print("3. Deposit")
        print("4. Exit")

        choice = int(input("Enter your choice (1-4): "))

        if choice == 1:
            print(f"Your current balance is: {balance:.2f}")

        elif choice == 2:
            withdraw_amount = float(input("Enter amount to withdraw: "))

            if withdraw_amount > balance:
                print("Insufficient balance.")
            elif withdraw_amount % 100 != 0 and withdraw_amount % 500 != 0:
                print("Withdrawal amount must be in multiples of 100 or 500.")
            else:
                balance -= withdraw_amount
                print(f"Withdrawal successful. New balance: {balance:.2f}")

        elif choice == 3:
            deposit_amount = float(input("Enter amount to deposit: "))
            balance += deposit_amount
            print(f"Deposit successful. New balance: {balance:.2f}")

        elif choice == 4:
            print("Thank you for using our ATM.")
            break

        else:
            print("Invalid choice. Please select a valid option.")


atm_transaction()
