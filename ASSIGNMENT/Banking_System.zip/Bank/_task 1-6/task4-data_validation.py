
account_numbers = [1010, 2020, 3030, 4040, 5050]
balances = [1500.75, 2450.00, 820.40, 9600.50, 124.90]

while True:
    # Get account number from user
    account_number = int(input("Enter your account number (or 0 to exit): "))

    # Check for exit condition
    if account_number == 0:
        print("Thank you for using our service!")
        break

    # Validate the account number
    if account_number in account_numbers:
        index = account_numbers.index(account_number)
        print(f"Account Number: {account_number}")
        print(f"Available Balance: ${balances[index]:.2f}\n")
    else:
        print("Invalid account number. Please try again.\n")
