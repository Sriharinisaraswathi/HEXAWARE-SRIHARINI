
transactions = []

while True:
    print("\n--- Bank Transaction Menu ---")
    print("1. Deposit")
    print("2. Withdraw")
    print("3. Exit and Show Transaction History")

    choice = int(input("Enter your choice (1-3): "))

    if choice == 1:
        amount = float(input("Enter deposit amount: "))
        transactions.append(f"Deposited: {amount:.2f}")
        print("Deposit successful!")

    elif choice == 2:
        amount = float(input("Enter withdrawal amount: "))
        transactions.append(f"Withdrawn: {amount:.2f}")
        print("Withdrawal successful!")

    elif choice == 3:
        print("\n--- Transaction History ---")
        if not transactions:
            print("No transactions made.")
        else:
            for transaction in transactions:
                print(transaction)
        print("Thank you for banking with us!")
        break

    else:
        print("Invalid choice. Please select a valid option.")
