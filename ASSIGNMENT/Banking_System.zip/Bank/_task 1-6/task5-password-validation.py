
password = input("Create your bank account password: ")

is_valid = True

if len(password) < 8:
    print("Password must be at least 8 characters long.")
    is_valid = False

if not any(char.isupper() for char in password):
    print("Password must contain at least one uppercase letter.")
    is_valid = False

if not any(char.isdigit() for char in password):
    print("Password must contain at least one digit.")
    is_valid = False

if is_valid:
    print("Password is valid and successfully created!")
else:
    print("Password creation failed. Please follow the password rules.")
