print("Loan Eligibility Checker")
credit_score = int(input("Enter the customer's credit score: "))
annual_income = float(input("Enter the customer's annual income : "))

# Checking eligibility using conditional statements
if credit_score > 700 and annual_income >= 50000:
    print("Congratulations! The customer is eligible for a loan.")
else:
    print("Sorry, the customer is not eligible for a loan.")
