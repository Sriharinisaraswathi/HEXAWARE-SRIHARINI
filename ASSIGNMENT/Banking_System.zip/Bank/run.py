from oops.main.MainModule import MainModule

if __name__ == "__main__":
    app = MainModule()
    app.main()
