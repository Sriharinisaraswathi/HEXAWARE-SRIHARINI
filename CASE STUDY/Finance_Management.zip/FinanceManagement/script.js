// Initialize transactions data
const transactions = [
  { 
    label: "Shopping", 
    date: "17th Feb 2025", 
    amount: -430, 
    icon: "fa-solid fa-bag-shopping"
  },
  { 
    label: "Travel", 
    date: "13th Feb 2025", 
    amount: -670, 
    icon: "fa-solid fa-plane"
  },
  { 
    label: "Salary", 
    date: "12th Feb 2025", 
    amount: 12000, 
    icon: "fa-solid fa-money-bill-wave"
  },
  { 
    label: "Loan Repayment", 
    date: "10th Feb 2025", 
    amount: -600, 
    icon: "fa-solid fa-hand-holding-dollar"
  },
  { 
    label: "Electricity Bill", 
    date: "11th Feb 2025", 
    amount: -200, 
    icon: "fa-solid fa-bolt"
  }
];

// Sample income and expense data
let incomes = [
  { 
    id: 1,
    category: "Salary", 
    amount: 12000, 
    date: "2025-02-12",
    description: "Monthly salary payment" 
  },
  { 
    id: 2,
    category: "Freelance", 
    amount: 1500, 
    date: "2025-02-18",
    description: "Website development project" 
  }
];

let expenses = [
  { 
    id: 1,
    category: "Shopping", 
    amount: 430, 
    date: "2025-02-17",
    description: "Grocery shopping at Walmart" 
  },
  { 
    id: 2,
    category: "Travel", 
    amount: 670, 
    date: "2025-02-13",
    description: "Flight tickets for vacation" 
  }
];

// Function to format currency
const formatCurrency = (amount) => {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0
  }).format(amount);
};

// Function to format date
const formatDate = (dateString) => {
  const options = { weekday: 'short', year: 'numeric', month: 'short', day: 'numeric' };
  return new Date(dateString).toLocaleDateString('en-US', options);
};

// Render transactions
const renderTransactions = () => {
  const list = document.getElementById("transaction-list");
  list.innerHTML = "";

  transactions.forEach((tx) => {
    const li = document.createElement("li");
    const formattedAmount = formatCurrency(Math.abs(tx.amount));
    
    li.innerHTML = `
      <i class="${tx.icon} transaction-icon"></i>
      <span>${tx.label} (${tx.date})</span>
      <span style="color: ${tx.amount < 0 ? '#f44336' : '#4CAF50'}">
        ${tx.amount < 0 ? '-' : '+'}${formattedAmount}
      </span>
    `;
    list.appendChild(li);
  });
};

// Initialize donut chart
const initChart = () => {
  const ctx = document.getElementById('donutChart').getContext('2d');
  const chart = new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: ['Total Balance', 'Total Expenses', 'Total Income'],
      datasets: [{
        data: [91100, 7100, 98200],
        backgroundColor: ['#7b47ff', '#f44336', '#ff5722'],
        borderWidth: 0
      }]
    },
    options: {
      cutout: '70%',
      plugins: {
        legend: {
          position: 'bottom',
          labels: {
            padding: 20,
            usePointStyle: true,
            pointStyle: 'circle',
            font: {
              size: 12
            }
          }
        }
      },
      elements: {
        arc: {
          borderWidth: 0
        }
      }
    }
  });
};

// Navigation functions
function showSection(sectionId) {
  // Hide all sections
  document.querySelectorAll('.content-section').forEach(section => {
    section.classList.remove('active');
  });
  
  // Remove active class from all sidebar items
  document.querySelectorAll('.sidebar nav ul li').forEach(item => {
    item.classList.remove('active');
  });
  
  // Show selected section and set active class
  document.getElementById(`${sectionId}-section`).classList.add('active');
  document.querySelector(`.sidebar nav ul li:nth-child(${
    sectionId === 'dashboard' ? 1 : 
    sectionId === 'income' ? 2 : 
    sectionId === 'expense' ? 3 : 4
  })`).classList.add('active');

  // Load specific content if needed
  if (sectionId === 'income') renderIncomes();
  if (sectionId === 'expense') renderExpenses();
}

function logout() {
  // In a real app, this would redirect to login page
  alert('Logging out... Redirecting to login page.');
  // window.location.href = '/login.html'; // Uncomment in real implementation
}

// Income Management
function renderIncomes() {
  const incomeList = document.querySelector('.income-list');
  incomeList.innerHTML = '';
  
  incomes.forEach((income) => {
    const item = document.createElement('div');
    item.className = 'income-item';
    item.innerHTML = `
      <div class="item-main-content">
        <h3>${income.category}</h3>
        <p class="date">${formatDate(income.date)}</p>
        ${income.description ? `<p class="description">${income.description}</p>` : ''}
      </div>
      <div class="item-footer">
        <div class="amount-container">
          <span class="amount">+${formatCurrency(income.amount)}</span>
        </div>
        <div class="item-actions">
          <button class="btn-view" onclick="viewIncome(${income.id})">View</button>
          <button class="btn-edit" onclick="editIncome(${income.id})">Edit</button>
        </div>
      </div>
    `;
    incomeList.appendChild(item);
  });
}

function showAddIncomeForm() {
  document.getElementById('add-income-form').style.display = 'block';
}

function hideAddIncomeForm() {
  document.getElementById('add-income-form').style.display = 'none';
}

function addIncome(event) {
  event.preventDefault();
  const form = event.target;
  const newIncome = {
    id: incomes.length + 1,
    category: form[0].value,
    amount: parseFloat(form[1].value),
    date: form[2].value,
    description: form[3].value
  };
  
  incomes.push(newIncome);
  renderIncomes();
  hideAddIncomeForm();
  form.reset();
}

// Expense Management
function renderExpenses() {
  const expenseList = document.querySelector('.expense-list');
  expenseList.innerHTML = '';
  
  expenses.forEach((expense) => {
    const item = document.createElement('div');
    item.className = 'expense-item';
    item.innerHTML = `
      <div class="item-main-content">
        <h3>${expense.category}</h3>
        <p class="date">${formatDate(expense.date)}</p>
        ${expense.description ? `<p class="description">${expense.description}</p>` : ''}
      </div>
      <div class="item-footer">
        <div class="amount-container">
          <span class="amount">-${formatCurrency(expense.amount)}</span>
        </div>
        <div class="item-actions">
          <button class="btn-view" onclick="viewExpense(${expense.id})">View</button>
          <button class="btn-edit" onclick="editExpense(${expense.id})">Edit</button>
        </div>
      </div>
    `;
    expenseList.appendChild(item);
  });
}

function showAddExpenseForm() {
  document.getElementById('add-expense-form').style.display = 'block';
}

function hideAddExpenseForm() {
  document.getElementById('add-expense-form').style.display = 'none';
}

function addExpense(event) {
  event.preventDefault();
  const form = event.target;
  const newExpense = {
    id: expenses.length + 1,
    category: form[0].value,
    amount: parseFloat(form[1].value),
    date: form[2].value,
    description: form[3].value
  };
  
  expenses.push(newExpense);
  renderExpenses();
  hideAddExpenseForm();
  form.reset();
}

// View/Edit Functions
function viewIncome(id) {
  const income = incomes.find(i => i.id === id);
  alert(`Income Details\n\nCategory: ${income.category}\nAmount: +${formatCurrency(income.amount)}\nDate: ${formatDate(income.date)}\nDescription: ${income.description || 'N/A'}`);
}

function editIncome(id) {
  const income = incomes.find(i => i.id === id);
  // In a real app, this would open a form with the income data
  alert(`Editing income: ${income.category}\n\nThis would open an edit form in a real implementation.`);
}

function viewExpense(id) {
  const expense = expenses.find(e => e.id === id);
  alert(`Expense Details\n\nCategory: ${expense.category}\nAmount: -${formatCurrency(expense.amount)}\nDate: ${formatDate(expense.date)}\nDescription: ${expense.description || 'N/A'}`);
}

function editExpense(id) {
  const expense = expenses.find(e => e.id === id);
  // In a real app, this would open a form with the expense data
  alert(`Editing expense: ${expense.category}\n\nThis would open an edit form in a real implementation.`);
}

// Initialize the dashboard
document.addEventListener('DOMContentLoaded', () => {
  renderTransactions();
  initChart();
  showSection('dashboard');
  
  // Set current date for forms
  const today = new Date().toISOString().split('T')[0];
  document.querySelectorAll('input[type="date"]').forEach(input => {
    input.value = today;
  });
});