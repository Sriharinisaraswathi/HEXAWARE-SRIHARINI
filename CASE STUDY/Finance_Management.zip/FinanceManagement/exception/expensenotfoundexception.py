class ExpenseNotFoundException(Exception):
    pass
