from flask import Flask, request, jsonify
from dao.financerepoimpl import FinanceRepoImpl
from flask_cors import CORS

app = Flask(__name__)
CORS(app)
finance_repo = FinanceRepoImpl()

@app.route('/login', methods=['POST'])
def login():
    data = request.json
    try:
        user = finance_repo.validate_user(data['email'], data['password'])
        return jsonify(user), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 401

@app.route('/register', methods=['POST'])
def register():
    data = request.json
    try:
        if finance_repo.user_exists(data['email']):
            return jsonify({"error": "User already exists"}), 400
        finance_repo.create_user(data['name'], data['email'], data['password'])
        return jsonify({"message": "User created successfully"}), 201
    except Exception as e:
        return jsonify({"error": str(e)}), 400

if __name__ == '__main__':
    app.run(debug=True, port=5000)
