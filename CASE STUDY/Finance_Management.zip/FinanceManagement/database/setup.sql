-- Create users table
CREATE TABLE users (
    user_id INT IDENTITY(1,1) PRIMARY KEY,
    username NVARCHAR(100) NOT NULL,
    email NVARCHAR(100) NOT NULL UNIQUE,
    password NVARCHAR(100) NOT NULL
);

-- Create expense_categories table
CREATE TABLE expense_categories (
    category_id INT IDENTITY(1,1) PRIMARY KEY,
    name NVARCHAR(50) NOT NULL
);

-- Create income_categories table
CREATE TABLE income_categories (
    category_id INT IDENTITY(1,1) PRIMARY KEY,
    name NVARCHAR(50) NOT NULL
);

-- Create expenses table
CREATE TABLE expenses (
    expense_id INT IDENTITY(1,1) PRIMARY KEY,
    user_id INT FOREIGN KEY REFERENCES users(user_id),
    category_id INT FOREIGN KEY REFERENCES expense_categories(category_id),
    amount DECIMAL(10,2) NOT NULL,
    date DATE NOT NULL,
    description NVARCHAR(200)
);

-- Create income table
CREATE TABLE income (
    income_id INT IDENTITY(1,1) PRIMARY KEY,
    user_id INT FOREIGN KEY REFERENCES users(user_id),
    category_id INT FOREIGN KEY REFERENCES income_categories(category_id),
    amount DECIMAL(10,2) NOT NULL,
    date DATE NOT NULL,
    description NVARCHAR(200)
);

-- Modify expense_categories table to add icon_url
ALTER TABLE expense_categories ADD icon_url NVARCHAR(255);

-- Modify income_categories table to add icon_url
ALTER TABLE income_categories ADD icon_url NVARCHAR(255);

-- Add default transaction images for categories
ALTER TABLE expense_categories ADD transaction_image_url NVARCHAR(255);
ALTER TABLE income_categories ADD transaction_image_url NVARCHAR(255);

-- Insert some default categories
INSERT INTO expense_categories (name) VALUES 
('Food'),
('Transportation'),
('Shopping'),
('Bills'),
('Entertainment');

INSERT INTO income_categories (name) VALUES 
('Salary'),
('Freelance'),
('Investment'),
('Business'),
('Other');

-- Update expense categories with Font Awesome icons
UPDATE expense_categories SET icon_url = CASE name
    WHEN 'Food' THEN 'fa-solid fa-utensils'
    WHEN 'Transportation' THEN 'fa-solid fa-car'
    WHEN 'Shopping' THEN 'fa-solid fa-cart-shopping'
    WHEN 'Bills' THEN 'fa-solid fa-file-invoice-dollar'
    WHEN 'Entertainment' THEN 'fa-solid fa-film'
END;

-- Update income categories with Font Awesome icons
UPDATE income_categories SET icon_url = CASE name
    WHEN 'Salary' THEN 'fa-solid fa-money-bill-wave'
    WHEN 'Freelance' THEN 'fa-solid fa-laptop-code'
    WHEN 'Investment' THEN 'fa-solid fa-chart-line'
    WHEN 'Business' THEN 'fa-solid fa-briefcase'
    WHEN 'Other' THEN 'fa-solid fa-circle-dot'
END;

-- Update expense categories list
INSERT INTO expense_categories (name) VALUES 
('Travel'),
('Electricity Bill'),
('Loan Repayment');

-- Update expense categories with Font Awesome icons
UPDATE expense_categories SET icon_url = CASE name
    WHEN 'Shopping' THEN 'fa-solid fa-bag-shopping'
    WHEN 'Travel' THEN 'fa-solid fa-plane'
    WHEN 'Electricity Bill' THEN 'fa-solid fa-bolt'
    WHEN 'Loan Repayment' THEN 'fa-solid fa-hand-holding-dollar'
    ELSE icon_url
END;

-- Update expense categories with transaction images
UPDATE expense_categories SET transaction_image_url = CASE name
    WHEN 'Shopping' THEN 'shopping-cart.jpg'
    WHEN 'Travel' THEN 'travel1.jpg'
    WHEN 'Electricity Bill' THEN 'electricity.jpg'
    WHEN 'Loan Repayment' THEN 'loan.jpg'
    WHEN 'Food' THEN 'food.jpg'
    WHEN 'Transportation' THEN 'transport.jpg'
    WHEN 'Bills' THEN 'bills.jpg'
    WHEN 'Entertainment' THEN 'entertainment.jpg'
    ELSE 'default.jpg'
END;

-- Update income categories with transaction images
UPDATE income_categories SET transaction_image_url = CASE name
    WHEN 'Salary' THEN 'salary.jpg'
    WHEN 'Freelance' THEN 'freelance.jpg'
    WHEN 'Investment' THEN 'investment.jpg'
    WHEN 'Business' THEN 'business.jpg'
    WHEN 'Other' THEN 'other.jpg'
    ELSE 'default.jpg'
END;

-- Add image support for transactions
ALTER TABLE expenses ADD image_url NVARCHAR(255);
ALTER TABLE income ADD image_url NVARCHAR(255);
