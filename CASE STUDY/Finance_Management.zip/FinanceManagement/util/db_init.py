from util.dbconnutil import DBConnUtil

def initialize_database():
    conn = None
    try:
        conn = DBConnUtil.get_connection()
        cursor = conn.cursor()
        
        # Create tables first
        # Create users table
        cursor.execute("""
        IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='users' and xtype='U')
        CREATE TABLE users (
            user_id INT IDENTITY(1,1) PRIMARY KEY,
            username NVARCHAR(100) NOT NULL,
            email NVARCHAR(100) NOT NULL UNIQUE,
            password NVARCHAR(100) NOT NULL
        )""")
        
        # Create expense_categories table
        cursor.execute("""
        IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='expense_categories' and xtype='U')
        CREATE TABLE expense_categories (
            category_id INT IDENTITY(1,1) PRIMARY KEY,
            category_name NVARCHAR(50) NOT NULL
        )""")
        
        # Create income_categories table
        cursor.execute("""
        IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='income_categories' and xtype='U')
        CREATE TABLE income_categories (
            category_id INT IDENTITY(1,1) PRIMARY KEY,
            category_name NVARCHAR(50) NOT NULL
        )""")
        
        # Create expenses table
        cursor.execute("""
        IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='expenses' and xtype='U')
        CREATE TABLE expenses (
            expense_id INT IDENTITY(1,1) PRIMARY KEY,
            user_id INT FOREIGN KEY REFERENCES users(user_id),
            category_id INT FOREIGN KEY REFERENCES expense_categories(category_id),
            amount DECIMAL(10,2) NOT NULL,
            date DATE NOT NULL,
            description NVARCHAR(200)
        )""")
        
        # Create income table
        cursor.execute("""
        IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='income' and xtype='U')
        CREATE TABLE income (
            income_id INT IDENTITY(1,1) PRIMARY KEY,
            user_id INT FOREIGN KEY REFERENCES users(user_id),
            category_id INT FOREIGN KEY REFERENCES income_categories(category_id),
            amount DECIMAL(10,2) NOT NULL,
            date DATE NOT NULL,
            description NVARCHAR(200)
        )""")

        # Commit table creation
        conn.commit()

        # Insert default expense categories
        cursor.execute("""
        IF NOT EXISTS (SELECT TOP 1 * FROM expense_categories)
        BEGIN
            INSERT INTO expense_categories (category_name) 
            VALUES 
                ('Food'),
                ('Transportation'),
                ('Shopping'),
                ('Bills'),
                ('Entertainment');
        END;
        """)

        # Insert default income categories
        cursor.execute("""
        IF NOT EXISTS (SELECT TOP 1 * FROM income_categories)
        BEGIN
            INSERT INTO income_categories (category_name)
            VALUES
                ('Salary'),
                ('Freelance'),
                ('Investment'),
                ('Business'),
                ('Other');
        END;
        """)

        # Final commit
        conn.commit()
        print("Database initialized successfully!")

    except Exception as e:
        print(f"Error initializing database: {str(e)}")
        if conn:
            try:
                conn.rollback()
                print("Changes rolled back successfully")
            except Exception as rollback_error:
                print(f"Error during rollback: {str(rollback_error)}")
        raise Exception("Database initialization failed. See above errors for details.")
    finally:
        if conn:
            try:
                conn.close()
            except Exception as close_error:
                print(f"Error closing connection: {str(close_error)}")
            print("Database connection closed.")
