from flask import Flask, request, jsonify
from dao.financerepoimpl import FinanceRepoImpl
from flask_cors import CORS

app = Flask(__name__)
CORS(app)
finance_repo = FinanceRepoImpl()

@app.route('/api/login', methods=['POST'])
def login():
    data = request.json
    try:
        user = finance_repo.validate_user(data['email'], data['password'])
        return jsonify(user), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 401

@app.route('/api/expenses', methods=['GET'])
def get_expenses():
    user_id = request.args.get('user_id')
    try:
        expenses = finance_repo.get_user_expenses(user_id)
        return jsonify(expenses), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 400

@app.route('/api/incomes', methods=['GET'])
def get_incomes():
    user_id = request.args.get('user_id')
    try:
        incomes = finance_repo.get_user_incomes(user_id)
        return jsonify(incomes), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 400

if __name__ == '__main__':
    app.run(debug=True, port=5000)
