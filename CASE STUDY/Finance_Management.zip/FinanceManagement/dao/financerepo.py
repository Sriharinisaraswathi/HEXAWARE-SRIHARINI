from abc import ABC, abstractmethod

class FinanceRepo(ABC):
    
    @abstractmethod
    def validate_user(self, username, password): pass

    @abstractmethod
    def get_user_expenses(self, user_id): pass

    @abstractmethod
    def get_user_incomes(self, user_id): pass
