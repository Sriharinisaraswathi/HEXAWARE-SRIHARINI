-- Create users table
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='users' and xtype='U')
CREATE TABLE users (
    user_id INT IDENTITY(1,1) PRIMARY KEY,
    username NVARCHAR(100) NOT NULL,
    email NVARCHAR(100) NOT NULL UNIQUE,
    password NVARCHAR(100) NOT NULL
);

-- Create expense categories table
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='expense_categories' and xtype='U')
CREATE TABLE expense_categories (
    category_id INT IDENTITY(1,1) PRIMARY KEY,
    name NVARCHAR(50) NOT NULL
);

-- Create income categories table
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='income_categories' and xtype='U')
CREATE TABLE income_categories (
    category_id INT IDENTITY(1,1) PRIMARY KEY,
    name NVARCHAR(50) NOT NULL
);

-- Create expenses table
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='expenses' and xtype='U')
CREATE TABLE expenses (
    expense_id INT IDENTITY(1,1) PRIMARY KEY,
    user_id INT FOREIGN KEY REFERENCES users(user_id),
    category_id INT FOREIGN KEY REFERENCES expense_categories(category_id),
    amount DECIMAL(10,2) NOT NULL,
    date DATE NOT NULL,
    description NVARCHAR(200)
);

-- Create income table
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='income' and xtype='U')
CREATE TABLE income (
    income_id INT IDENTITY(1,1) PRIMARY KEY,
    user_id INT FOREIGN KEY REFERENCES users(user_id),
    category_id INT FOREIGN KEY REFERENCES income_categories(category_id),
    amount DECIMAL(10,2) NOT NULL,
    date DATE NOT NULL,
    description NVARCHAR(200)
);

-- Insert default expense categories
IF NOT EXISTS (SELECT TOP 1 * FROM expense_categories)
BEGIN
    INSERT INTO expense_categories (name)
    VALUES ('Food'),('Transportation'),('Shopping'),('Bills'),('Entertainment');
END

-- Insert default income categories
IF NOT EXISTS (SELECT TOP 1 * FROM income_categories)
BEGIN
    INSERT INTO income_categories (name)
    VALUES ('Salary'),('Freelance'),('Investment'),('Business'),('Other');
END
