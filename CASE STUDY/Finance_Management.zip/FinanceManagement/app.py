from flask import Flask, render_template, request, redirect, session, flash, url_for, send_from_directory, make_response
import os
from dao.financerepoimpl import FinanceRepoImpl
from exception.invaliduserexception import InvalidUserException
from datetime import datetime, timedelta
from util.db_init import initialize_database

app = Flask(__name__, static_url_path='/static', static_folder='static')
app.secret_key = 'supersecret123'

# Initialize the database when the app starts
initialize_database()

finance_repo = FinanceRepoImpl()

# Configure static folder structure
APP_ROOT = os.path.dirname(os.path.abspath(__file__))
STATIC_FOLDER = os.path.join(APP_ROOT, 'static')
IMAGES_FOLDER = os.path.join(STATIC_FOLDER, 'images')
ASSETS_FOLDER = os.path.join(STATIC_FOLDER, 'assets')

# Default asset paths
DEFAULT_AVATAR = 'default-avatar.png'
DEFAULT_ICON = 'default-icon.png'

# Create required directories if they don't exist
os.makedirs(STATIC_FOLDER, exist_ok=True)
os.makedirs(IMAGES_FOLDER, exist_ok=True)
os.makedirs(ASSETS_FOLDER, exist_ok=True)

# Create default assets if they don't exist
# You can remove or comment out the default_files section since we'll handle assets differently
# Remove or comment this section:
# default_files = {
#     os.path.join(ASSETS_FOLDER, DEFAULT_AVATAR): '...',
#     os.path.join(ASSETS_FOLDER, DEFAULT_ICON): '...'
# }

@app.route('/static/<path:filename>')
def serve_static(filename):
    """Generic static file handler with cache control"""
    response = make_response(send_from_directory(STATIC_FOLDER, filename))
    # Disable caching for static files
    response.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate, max-age=0'
    response.headers['Pragma'] = 'no-cache'
    response.headers['Expires'] = '0'
    return response

@app.route('/')
def show_login():
    return render_template('login.html')

@app.route('/login', methods=['POST'])
def login():
    email = request.form['email']
    password = request.form['password']
    try:
        user = finance_repo.validate_user(email, password)
        session['user_id'] = user['user_id']
        session['email'] = user['email']
        return redirect('/dashboard')
    except InvalidUserException as e:
        flash(str(e))
        return redirect('/')

@app.route('/signup', methods=['POST'])
def signup():
    name = request.form['name']
    email = request.form['email']
    password = request.form['password']
    
    try:
        # Check if user already exists
        if finance_repo.user_exists(email):
            flash("User with this email already exists!")
            return redirect('/')
            
        # Create new user
        finance_repo.create_user(name, email, password)
        flash("Account created successfully! Please login.")
        return redirect('/')
        
    except Exception as e:
        flash(str(e))
        return redirect('/')

@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect('/')
    user_id = session['user_id']
    expenses = finance_repo.get_user_expenses(user_id)
    incomes = finance_repo.get_user_incomes(user_id)
    exp_categories = finance_repo.get_expense_categories()
    inc_categories = finance_repo.get_income_categories()
    
    # Add total calculations
    total_income = sum(income['amount'] for income in incomes)
    total_expenses = sum(expense['amount'] for expense in expenses)
    total_balance = total_income - total_expenses
    
    return render_template(
        'index.html',
        username=session['email'],
        expenses=expenses,
        incomes=incomes,
        exp_categories=exp_categories,
        inc_categories=inc_categories,
        total_income=total_income,
        total_expenses=total_expenses,
        total_balance=total_balance
    )

@app.route('/add-expense', methods=['POST'])
def add_expense():
    if 'user_id' not in session:
        return redirect('/')
    user_id = session['user_id']
    category_id = int(request.form['expense_category'])
    amount = float(request.form['expense_amount'])
    date = request.form['expense_date']
    description = request.form['expense_desc']
    finance_repo.add_expense(user_id, category_id, amount, date, description)
    flash("Expense added successfully!")
    return redirect('/dashboard')

@app.route('/add-income', methods=['POST'])
def add_income():
    if 'user_id' not in session:
        return redirect('/')
    user_id = session['user_id']
    category_id = int(request.form['income_category'])
    amount = float(request.form['income_amount'])
    date = request.form['income_date']
    description = request.form['income_desc']
    finance_repo.add_income(user_id, category_id, amount, date, description)
    flash("Income added successfully!")
    return redirect('/dashboard')

@app.route('/edit-expense/<int:expense_id>', methods=['GET', 'POST'])
def edit_expense(expense_id):
    if 'user_id' not in session:
        return redirect('/')
    if request.method == 'POST':
        user_id = session['user_id']
        category_id = int(request.form['expense_category'])
        amount = float(request.form['expense_amount'])
        date = request.form['expense_date']
        description = request.form['expense_desc']
        finance_repo.update_expense(expense_id, user_id, category_id, amount, date, description)
        flash("Expense updated successfully!")
        return redirect('/dashboard')
    else:
        # Fetch current data and pass it to form
        return render_template('edit_expense.html', expense_id=expense_id)

@app.route('/edit-income/<int:income_id>', methods=['GET', 'POST'])
def edit_income(income_id):
    if 'user_id' not in session:
        return redirect('/')
    if request.method == 'POST':
        user_id = session['user_id']
        category_id = int(request.form['income_category'])
        amount = float(request.form['income_amount'])
        date = request.form['income_date']
        description = request.form['income_desc']
        finance_repo.update_income(income_id, user_id, category_id, amount, date, description)
        flash("Income updated successfully!")
        return redirect('/dashboard')
    else:
        # Fetch current data and pass it to form
        return render_template('edit_income.html', income_id=income_id)

@app.route('/delete-expense/<int:expense_id>', methods=['POST'])
def delete_expense(expense_id):
    if 'user_id' not in session:
        return redirect('/')
    user_id = session['user_id']
    finance_repo.delete_expense(expense_id, user_id)
    flash("Expense deleted successfully!")
    return redirect('/dashboard')

@app.route('/delete-income/<int:income_id>', methods=['POST'])
def delete_income(income_id):
    if 'user_id' not in session:
        return redirect('/')
    user_id = session['user_id']
    finance_repo.delete_income(income_id, user_id)
    flash("Income deleted successfully!")
    return redirect('/dashboard')

@app.route('/logout')
def logout():
    session.clear()
    return redirect('/')

if __name__ == '__main__':
    app.run(debug=True)
